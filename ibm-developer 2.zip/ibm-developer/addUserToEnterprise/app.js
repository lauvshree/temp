const express = require("express");
const bodyParser = require("body-parser");
const ResourceManagerV2 = require('@ibm-cloud/platform-services/resource-manager/v2');
const IamPolicyManagementV1 = require('@ibm-cloud/platform-services/iam-policy-management/v1');
const UserManagementV1 = require('@ibm-cloud/platform-services/user-management/v1');
const ResourceControllerV2 = require('@ibm-cloud/platform-services/resource-controller/v2');
const jwt = require('jsonwebtoken');
const session = require('express-session')
const lti = require('ims-lti');
require("dotenv").config();
const nonceStore = new lti.Stores.MemoryStore();
const cors = require('cors');
const routes = require("./src/routes");
const app = express();

app.use(cors())

const {
  PORT,
  CLIENT_LICENSE_KEY
} = process.env;


const port = PORT || 8080;

app.set("view engine", "ejs");
app.use(express.static("./build/"));
app.use(session({secret:"secret",resave: true, saveUninitialized: true}))
app.use("/*", bodyParser.urlencoded({ extended: false }));
app.use("/*", bodyParser.json());

routes(app)

app.use("learnerservice/*", (req,res,next)=>{
     if(req.session.authorization) {
         let token = req.session.authorization['accessToken']; // Access Token
         jwt.verify(token, "access",(err,user)=>{
            if(!err){
              req.user = user;
              next();
            }
            else{
              return res.status(403).json({message: "User not authenticated"})
            }
          });
      } else {
          return res.status(403).json({message: "User not authenticated"})
      }
});

/**
 * Validate OAuth Signature for the request
 *
 * author Neeraj Avinash
 */
function validate_oauth_signature(req) {
  const oauthReqest = req.body;

  //console.log(oauthReqest);

  //console.log(req.headers);

  //console.log("req.protocol "+req.protocol);

  req.protocol = "https";

  //console.log("updated req.protocol "+req.protocol);

  const url = require('url');
  const originalUrl = req.originalUrl || req.url;
  const pathname = url.parse(originalUrl, true).pathname
  console.log(pathname)
  
  const consumer_key = oauthReqest.oauth_consumer_key;
  const consumer_secret = CLIENT_LICENSE_KEY;
  
  console.log(consumer_secret);

  const provider = new lti.Provider(consumer_key, consumer_secret, lti.HMAC_SHA1);


  let isValidSignature = provider.valid_request(req, (err, isValid) => {
    if (err) {
      console.log("Error ----   "+err);
    }


    if (isValid) {
      let accessToken = jwt.sign({
        data: req.body
      }, 'access', { expiresIn: 60 * 60 });
  
      req.session.authorization = {
        accessToken
    }
      return true;
    } else {
      return false;
    }
  })
  return isValidSignature;

}

/**
 * Entry point from course Dashboard.
 *
 * Acts as a bridge between course LMS and IBM. Renders intermediary React app.
 *
 * Takes request and passes request back to React app for further processing.
 *
 * author Neeraj Avinash
 */
app.post("/start", (req, res, next) => {
  const isValidSignature = validate_oauth_signature(req);
  let data = {
    req: req.body,
    validSignature: isValidSignature,
  };
  res.render("index", { data });
});

app.listen(port, () => console.log(`Listening at :${port}`));
