import axios from "axios";
import { useEffect, useState } from "react";
import "./App.css";

const apiHost = "http://localhost:8080"; // Local development
//const apiHost = ""; // Leave empty for prod

function App() {
  const reqDataObject = window.__userData || {
    validSignature: true,
    req: {
      lis_person_contact_email_primary: "example@skillup.online",
      lis_person_name_full: " ",
      //custom_action: "invite",
      custom_action: "create_service",
      custom_plan: "WatsonAssistant",
      custom_servicename: "WatsonAssistant"
    }
  };

  // Code to simulate request on local development
  /*
  const reqDataObject = {
    req: {
      oauth_callback: "about:blank",
      launch_presentation_return_url: "",
      lti_message_type: "basic-lti-launch-request",
      lti_version: "LTI-1p0",
      resource_link_id:
        "courses.skillup-dev.skillsnetwork.site-9b16259b4fe64442836c806e6f5469a3",
      user_id: "6c436ed3173c34ce5abc42f81dea0a17",
      roles: "Student",
      lis_result_sourcedid:
        "course-v1%3AIBM%2BIBMLTITEST%2B2022:courses.skillup-dev.skillsnetwork.site-9b16259b4fe64442836c806e6f5469a3:6c436ed3173c34ce5abc42f81dea0a17",
      lis_person_sourcedid: "neerajbg",
      lis_person_contact_email_primary: "neerajbg@gmail.com",
      context_id: "course-v1:IBM+IBMLTITEST+2022",
      context_title: "IBM Cloud - Test LTI",
      context_label: "IBM",
      launch_presentation_locale: "en",
      custom_action: "invite",
      custom_servicename: "MachineLearning",
      custom_component_display_name:
        "Create Your Machine Learning Instance at IBM",
      custom_plan: "lite",
      oauth_timestamp: "1665997112",
      oauth_version: "1.0",
      oauth_signature_method: "HMAC-SHA1",
      oauth_consumer_key: "MY_SKO_KEY",
      oauth_signature: "H6iuv6kigvMZNOhBdKEhlzKHZrw=",
      oauth_nonce: "84605176791477158211665997112",
    },
    validSignature: true,
  };
  */

 /*const reqData = reqDataObject?.req;
 const validSignature = reqDataObject?.validSignature;*/
  // console.log(reqData);

  const [loading, setLoading] = useState(true);
  const [apiMsg, setApiMsg] = useState(false);
  const [errorMsg, setErrorMsg] = useState(false);
  const [userFromError, setUserFromError] = useState(null);
  const [reqData, setReqData] = useState(reqDataObject?.req);
  const [validSignature, setValidSignature] = useState(reqDataObject?.validSignature);

  // Loading Mesage
  const [loadingMsg, setLoadingMsg] = useState(false);

  let tempData = "";

  const redoInvitation = async (data)=>{
    let apiUrl = `${apiHost}/learnerservice/redo`
    setLoading(true)
    try{
      const response = await axios.post(apiUrl, data);
      console.log(response)
      tempData = `<h2 class="success">Success!</h2>
      ${response.data?.message || ""}
      `;
      setApiMsg(tempData);
    }catch(error){
      console.log(error)
      tempData = `
      ${
        error.response.data?.message
          ? error.response.data?.message
          : "<p>Something went wrong!</p>"
      }</h5>
        `;
      setApiMsg(tempData);
    }finally{
      setLoading(false)
    }
  }
  
  useEffect(()=>{
    if(userFromError){
      const button = document.querySelector("#redo");
      button?.addEventListener("click", ()=> redoInvitation({iamId: userFromError.iam_id, email:userFromError.email, firstName:userFromError.firstName}))
    }
  },[apiMsg])

  // Invite User
  const invite_user = async (data) => {
    let apiUrl = `${apiHost}/learnerservice/lti`;

    try {
      data.react_secret = "secret";
      const response = await axios.post(apiUrl, data);
      tempData = `<h2 class="success">Success!</h2>
      ${response.data?.message || ""}
      `;

      setApiMsg(tempData);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      tempData = `
      ${
        error.response.data?.message
          ? (
            `<div>
              <p>${error.response.data?.message}</p>
              ${error.response.data.data.state == "PENDING" ? ('<p>In case you want to get a new link, please <button id="redo">click here</button></p>'):""}
            </div>`
            )
          : "<p>Something went wrong!</p>"
      }</h5>
        `;
      setUserFromError(error.response.data.data)
      setApiMsg(tempData);
      console.log("400 response ", error);
    }
  };

  // Create Service Instance

  const create_service = async (data) => {
    let apiUrl = `${apiHost}/learnerservice/createServiceInstance`;

    try {
      const response = await axios.post(apiUrl, data);

      tempData = `
      <h2 class="success">Success!</h2>
      ${response.data?.message}
        <p>
        You can <a href="https://cloud.ibm.com/resources">click here</a> to view all your IBM Cloud resources.
        </p>`;

      setApiMsg(tempData);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      let tempData = `
        <h2 class="error">Error!</h2>${
          error.response.data?.message
            ? error.response.data?.message
            : "<p>Something went wrong! Resource could not be created. </p>"
        }
        <p>
        You might have created this resource already. Please check <a href="https://cloud.ibm.com/resources">click here</a> to view all your IBM Cloud resources.
        </p>`;

      setApiMsg(tempData);
      setErrorMsg(tempData);

      console.log("400 response ", errorMsg);
    }
  };

  // Make API call
  useEffect(() => {
    if (reqData && validSignature) {
      switch (reqData.custom_action) {
        case "invite":
          setLoadingMsg(
            `<h2>Please wait...</h2><p>We are Inviting you to the IBM cloud.</p>`
          );
          invite_user(reqData);
          break;
        case "create_service":
          setLoadingMsg(
            "<h2>Please wait...</h2><p>We are creating a " +
              reqData.custom_plan.charAt(0).toUpperCase() +
              reqData.custom_plan.slice(1) +
              " instance of " +
              reqData.custom_servicename +
              " </p><p>service for you on IBM cloud.</p>" +
              "<br/>"
          );
          create_service(reqData);
          break;
        default:
          break;
      }
    }
  }, [reqData]);

  return (
    <div className="App">
      {/* <header>
        <h2>{reqData?.context_title}</h2>
      </header> */}

      <div className="container">
        <div className="box-m">
          <div className="box-item">
            <div className="respHld">
              {!validSignature ? (
                <p className="error">
                  You are not authorized to access this resource. Your signature
                  is invalid. Please try again.
                </p>
              ) : (
                <>
                  {loading ? (
                    <>
                      <div className="txt-center highlight mb">
                        {loadingMsg ? (
                          <div
                            dangerouslySetInnerHTML={{ __html: loadingMsg }}
                          ></div>
                        ) : (
                          "We are processing your request ."
                        )}
                      </div>
                      <div className="spinner-container">
                        <div className="loading-spinner"></div>
                      </div>
                    </>
                  ) : (
                    <div
                      className="txt-center"
                      dangerouslySetInnerHTML={{ __html: apiMsg }}
                    />
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* <footer>
        <h2>FAQ</h2>
      </footer> */}
    </div>
  );
}

export default App;
