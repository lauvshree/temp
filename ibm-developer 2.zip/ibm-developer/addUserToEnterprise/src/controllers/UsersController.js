const User = require("../models/UsersModel");

class UserController extends User{

    constructor(){
        super()
    }

    static async inviteNewUser(req, res){
        let email = req.body.lis_person_contact_email_primary;
        let name = req.body.lis_person_name_full;

        try{
            const listOfUsers = await User.getUsersList();
            let users = listOfUsers.filter((user) => user.email === email);
            
            if (users.length > 0 && users[0].state == "PENDING") {
            const error = new Error(`You have already requested to join the enterprise account. Please check your email(${email}) to get the activation link. In case you don't find in your inbox, please check your SPAM/Junk folder`);
            error.status = 400
            error.data = users[0]
            throw error

            }else if (users.length > 0 && users[0].state == "ACTIVE") {
            const error = new Error(`Your account exists with this email(${email}) address on Enterprise cloud. You can skip this step and directly log on to IBM cloud account to get started. In case you have forgotten your password, you can reset your password`);
            error.status = 400
            error.data = users[0]
            throw error

            }else{
            const groupVerification = await User.findOrCreateResourceGroup(email);
            const userIvited = await User.inviteUser(email, name, "MEMBER", groupVerification);
            res.status(userIvited.status || 200).json({"user": userIvited.result.resources, "group_id": groupVerification});
            };

        }catch(err){
            //console.log(err)
            res.status(err.status || 500).json({message: err.message, data: err.data})
        }
    }

    static async recreateUser(req, res){
        const {iamId, email, firstName} = req.body;
        try{
            const deletion = await User.removeUser(iamId);

            if(deletion.status > 300){
                const error = new Error(`was not possible delete the user with email ${email} and imId ${iamId}`);
                error.status = deletion.status || 400;
                throw error
            }else{
                const groupVerification = await User.findOrCreateResourceGroup(email);
                const newUser = await User.inviteUser(email, firstName, "MEMBER", groupVerification);
                res.status(newUser.status || 200).json({"user": newUser.result.resources, "group_id": groupVerification});
            }
        }catch(err){
            res.status(err.status || 500).json({message: err.message, data: err.data})
        }
    }
}

module.exports = UserController;