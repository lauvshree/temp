const UserCrontroller = require("./UsersController");
const ServicesInstancesController = require("./ServicesInstancesController");

module.exports={
    UserCrontroller,
    ServicesInstancesController
};