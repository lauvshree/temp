const ServiceInstance = require("../models/ServicesInstancesModel");
const User = require("../models/UsersModel");

class ServiceInstanceController extends ServiceInstance{

    constructor(){
        super()
    }

    static async createNewServiceInstance(req,res){
        let service = req.body.custom_servicename;
        let plan = req.body.custom_plan;
        let email = req.body.lis_person_contact_email_primary;

        try{
            const usersListResult = await User.getUsersList();
            const user = usersListResult.filter((user) => user.email === email);

            if (user.length > 0) {
                const groupId = await User.getResourceGroupId(email);
                const userPermitions = await User.checkUserPermissions(email, groupId);

                const serviceCreation = await ServiceInstance.findOrCreateServiceInstance(req, email, groupId);
                res.status(serviceCreation.status || 200).json({message: `The ${plan}, instance of ${service}, service for ${email} has been successfully created.`})
            }else{
                const error = new Error();
                error.status = 400;
                throw error;
            }
        }catch(err){
            res.status(err.status || 500).json({
                message: err.message || "This user does not have enterprise access. To try again please accept invitation",
                data: err.data
            });
        }
    }
};

module.exports=ServiceInstanceController;