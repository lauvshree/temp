const { Router } = require("express");
const ServiceInstanceController = require("../controllers/ServicesInstancesController");
const router = Router();

router  .post("/learnerservice/createServiceInstance", ServiceInstanceController.createNewServiceInstance)

module.exports = router;