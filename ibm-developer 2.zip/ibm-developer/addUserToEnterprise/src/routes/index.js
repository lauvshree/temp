const userRoutes = require("./usersRoutes");
const servicesInstancesRoutes = require("./servicesInstancesRoutes");

module.exports = app => {
    app.use(
        userRoutes,
        servicesInstancesRoutes
    )
}