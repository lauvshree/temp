const { Router } = require("express");
const UserController = require("../controllers/UsersController");
const router = Router();

router
    .post("/learnerservice/lti", UserController.inviteNewUser)
    .post("/learnerservice/redo", UserController.recreateUser)

module.exports = router;