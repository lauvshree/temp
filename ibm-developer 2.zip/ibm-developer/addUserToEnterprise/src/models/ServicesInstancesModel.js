const ResourceControllerV2 = require('@ibm-cloud/platform-services/resource-controller/v2');

class ServiceInstance{
    static async findOrCreateServiceInstance(req, email, grp_id){
        const service = req.body.custom_servicename;
        const serviceClient = ResourceControllerV2.newInstance({});
        const instance_name = service + "_" + email.replace(/[^\w\s]/gi, "");
        const allResults = [];
      
        const pager = new ResourceControllerV2.ResourceInstancesPager(serviceClient, {name: instance_name});
      
        while (pager.hasNext()) {
          const nextPage = await pager.getNext();
          //expect(nextPage).not.toBeNull();
          allResults.push(...nextPage);
        }
        //console.log("all results", allResults)
      
        if(allResults.length > 0){
          const error = new Error(`The instance you are trying to create already exists. Please log in to your cloud account to start using the instance`)
          error.status = 409;
          throw error;
        }else{
          const newServiceInstance = await this.createService(req, serviceClient, instance_name, grp_id);
          return newServiceInstance;
        }
    }

    static async createService(req, serviceClient, instance_name, grp_id) {
        try{
            let resourcePlanId = process.env.STUDIO_LITE_PLAN; //Default lite plan for WS
            let service = req.body.custom_servicename;
            let plan = req.body.custom_plan;
            plan = plan.charAt(0).toUpperCase() + plan.slice(1);
            let target = "eu-gb";
      
            switch (service) {
                case "WatsonStudio":
                    resourcePlanId = process.env.STUDIO_LITE_PLAN;
                    target = "us-south";
                    break;
                case "Cloudant":
                    resourcePlanId = process.env.CLOUDANT_LITE_PLAN;
                    break;
                case "DB2":
                    resourcePlanId = process.env.DB2_LITE_PLAN;
                    break;
                case "WatsonAssistant":
                    resourcePlanId = process.env.ASSISTANT_LITE_PLAN;
                    break;
                case "Discovery":
                    resourcePlanId = process.env.DISCOVERY_LITE_PLAN;
                    break;
                case "MachineLearning":
                    resourcePlanId = process.env.ML_LITE_PLAN;
                    break;
                case "NLU":
                    resourcePlanId = process.env.NLU_LITE_PLAN;
                    break;
                case "Translator":
                    resourcePlanId = process.env.TRANSLATOR_LITE_PLAN;
                    break;
                case "TextToSpeech":
                    resourcePlanId = process.env.TTS_LITE_PLAN;
                    break;
                case "SpeechToText":
                    resourcePlanId = process.env.STT_LITE_PLAN;
                    break;
            }
            const newResourceInstance = await serviceClient.createResourceInstance({
                name: instance_name,
                target: target,
                resourceGroup: grp_id,
                resourcePlanId,
            });
            return newResourceInstance;
        }catch(err){
            const error = new Error(err.message || "was not possible to create a new instance");
            error.status = err.status || 400;
            throw error
        }
    }
}

module.exports = ServiceInstance;