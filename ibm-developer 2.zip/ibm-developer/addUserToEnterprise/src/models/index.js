const User = require("./UsersModel");
const ServicesInstancesModel = require("./ServicesInstancesModel");

module.exports={
    User,
    ServicesInstancesModel
};