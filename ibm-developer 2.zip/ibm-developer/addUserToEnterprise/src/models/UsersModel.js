const ResourceManagerV2 = require('@ibm-cloud/platform-services/resource-manager/v2');
const IamPolicyManagementV1 = require('@ibm-cloud/platform-services/iam-policy-management/v1');
const UserManagementV1 = require('@ibm-cloud/platform-services/user-management/v1');

class User{
  static accountId = process.env.ACCOUNT_ID;
  static limit = 100;

  //deprecated function to list users, replaced, by the new function to satisfy the API new version requirements, in 31/03/2023
  /*async function getUsersList(params) {
  const list = [];
  const userManagementService = UserManagementV1.newInstance({});
  let users = await userManagementService.listUsers(params);
  list.push.apply(list, users.result.resources);

  while (users.result.next_url) {
    let i = users.result.next_url.indexOf("_start=") + 7;
    let j = users.result.next_url.indexOf("&limit");
    params.start = users.result.next_url.substring(i, j);
    users =  await userManagementService.listUsers(params);
    list.push.apply(list, users.result.resources);
  }

  if(list.length < 300){
    delete params.start;
    return getUsersList(params)
  }

  //console.log(list.length);
  return list
}*/

  //new function to list users, implemented to satisfy the new API version requirements in 31/03/2023
  static async getUsersList(){
    const allResults = []; 
    const userManagementService = UserManagementV1.newInstance({});

    try { 
      const pager = new UserManagementV1.UsersPager(userManagementService, {accountId: this.accountId, limit: this.limit});

      while (pager.hasNext()) { 
        const nextPage = await pager.getNext(); 
        if(nextPage != null){
          allResults.push(...nextPage);
        } 
      }
      
      return allResults;
    }catch (err) { 
      console.warn(err); 
    } 
  }

  static async inviteUser(email, name, account_role,accessGroupId){
    const inviteUserModel = {
      email,
      name,
      account_role,
    };

    const params = {
      accountId: this.accountId,
      users: [inviteUserModel],
      //accessGroups: [accessGroupId]
    };

    try{
      const userManagementAdminService = UserManagementV1.newInstance({});
      const userIvited = await userManagementAdminService.inviteUsers(params)
      return userIvited
    }catch(err){
      const error = new Error(`Unable to add user. ${err}`);
      error.status = error.status = err.code || 400;
      throw error;
    };
  }

  static async findOrCreateResourceGroup(email){
    const groupId = await this.getResourceGroupId(email);

    if (!groupId) {
      const serviceClient = ResourceManagerV2.newInstance({});
      let groupname = email.replace(/[^\w\s]/gi, "");

      const params = {
        accountId: this.accountId,
        name: groupname,
      };
      try{
        const groupId = await serviceClient.createResourceGroup(params)
        const grp_id = groupId.result.id
        return grp_id
      }catch(err){
        console.log("Unable to create resource group " + err);
      };
    }else{
      return groupId
    }
  }

  static async getResourceGroupId(email) {
    try{
      let groupname = email.replace(/[^\w\s]/gi, "");
      const response = await this.getResourceGroupsList();
      let resourcegroup = response.result.resources.filter(
        (element) => element.name == groupname
      );
      if (resourcegroup.length > 0) {
        return resourcegroup[0].id;
      }else{
        return false
      }
    }catch(err){
      const error = new Error(err.message || "was not possible to get resource groups id")
      error.status = err.code || 500;
      throw error
    }
  }

  static async getResourceGroupsList() {
    const serviceClient = ResourceManagerV2.newInstance({});
    const params = {
      accountId: this.accountId,
    };
    return serviceClient.listResourceGroups(params);
  }

  static async removeUser(iamId){
    const params = {
      accountId: this.accountId,
      iamId,
    };
    
    try {
      const userManagementService = UserManagementV1.newInstance({});
      const deletion = await userManagementService.removeUser(params);
      return deletion
  
    } catch (err) {
      console.log(err);
      const error = new Error(`Impossible delete user. ${err}`);
      error.status = err.code || 404
      throw error
    }
  }

  static async checkUserPermissions(email, grp_id) {
    const iamPolicyManagementService = IamPolicyManagementV1.newInstance({});
    let finalPolicy =false;
    try{
      const usersListResult = await this.getUsersList();
      let users = usersListResult.filter((user) => user.email === email);
      const params = {
        accountId: users[0].account_id,
        iamId: users[0].iam_id,
        type: "access",
      };
      let toCreateEditorPolicy = false;
      let toCreateOWRPolicy = false;
      const policiesListResponse = await iamPolicyManagementService.listPolicies(params);
      const policiesList = policiesListResponse.result.policies;
  
      if (policiesList.length == 0) {
        toCreateEditorPolicy = true;
        toCreateOWRPolicy = true;
      }else {
        finalPolicy = policiesListResponse.result.policies[0];
        policiesList.forEach((policy) => {
          let policyForRG = policy.resources[0].attributes.filter(
            (attribute) => {
              return (
                attribute.name === "resourceGroupId" &&
                attribute.value === grp_id
              );
            }
          );
          
          if (policyForRG.length > 0) {
            if (
              policy.roles.filter((role) => role.display_name === "Editor")
                .length == 0
            ) {
              return toCreateEditorPolicy = true;
            }
            if (
              policy.roles.filter((role) => {
                return (
                  role.display_name === "Operator" ||
                  role.display_name === "Reader" ||
                  role.display_name === "Writer"
                );
              }).length == 0
            ) {
              return toCreateOWRPolicy = true;
            }
          }
        });
      }
      
      if (toCreateOWRPolicy || toCreateEditorPolicy) {
        let user_params = {
          type: "access",
          roles: [
            {
              role_id: "crn:v1:bluemix:public:iam::::role:Operator",
            },
            {
              role_id: "crn:v1:bluemix:public:iam::::serviceRole:Reader",
            },
            {
              role_id: "crn:v1:bluemix:public:iam::::serviceRole:Writer",
            },
            {
              role_id: "crn:v1:bluemix:public:iam::::role:Editor",
            },
          ],
          resources: [
            {
              attributes: [
                {
                  name: "accountId",
                  value: users[0].account_id,
                },
                {
                  name: "resourceGroupId",
                  value: grp_id,
                },
              ],
            },
          ],
          subjects: [
            {
              attributes: [
                {
                  name: "iam_id",
                  value: users[0].iam_id,
                },
              ],
            },
          ],
        };

        finalPolicy = await iamPolicyManagementService.createPolicy(user_params);
        console.log("Policies created", finalPolicy);
      }
      return finalPolicy
    }catch(err){
      console.log(err)
      throw err
    }
  }
}

module.exports=User