"""
Sample code for detecting the LTI provider (e.g. Coursera), the lab name, and the course name for a given LTI request
"""

def guess_lti_provider(lti_request_params=None):
    lti_request_params = {} if lti_request_params is None else lti_request_params
    provider = "Unknown Learning Platform"
    try:
        if "courses.edx.org" in lti_request_params.get("resource_link_id", ""):
            provider = "edX"
        elif "Coursera" in lti_request_params.get("tool_consumer_instance_description", ""):
            provider = "Coursera"
        else:
            provider = lti_request_params.get("resource_link_id").rsplit("-", 1)[0]
    except Exception:
        # unable to identify provider
        pass
    return provider

def guess_lab_name(lti_request_params=None):
  paralti_request_paramsms = {} if lti_request_params is None else lti_request_params
  lab_name = lti_request_params.get("custom_component_display_name") or lti_request_params.get("resource_link_title") or "Unknown Lab"
  return lab_name

def guess_course_name(lti_request_params=None):
    lti_request_params = {} if lti_request_params is None else lti_request_params
    course_name = params.get("context_title") or "Unknown Course"
    return course_name
